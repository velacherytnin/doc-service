<html>
<head>
<style>
  table {
    border-collapse: collapse;
    width: 100%;
  }
  table tr:nth-child(even) {
    background-color: transparent; /* Remove alternating row color */
  }
  table tr:nth-child(odd) {
    background-color: transparent; /* Remove alternating row color */
  }
</style>
</head>
<table>
  <tr>
    <td><strong>Header 1</strong></td>
    <td>Data 1</td>
    <td>Data 2</td>
    <td>Data 3</td>
  </tr>
  <tr>
    <td><strong>Header 2</strong></td>
    <td>Data 4</td>
    <td>Data 5</td>
    <td>Data 6</td>
  </tr>
  <tr>
    <td><strong>Header 3</strong></td>
    <td>Data 7</td>
    <td>Data 8</td>
    <td>Data 9</td>
  </tr>
</table>